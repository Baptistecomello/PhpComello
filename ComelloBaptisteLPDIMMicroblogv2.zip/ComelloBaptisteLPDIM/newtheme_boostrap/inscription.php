<?php 
require("libs/Smarty.class.php");

require("includes/haut.inc.php");

require("includes/connexion.inc.php");

$sql = "SELECT * FROM user";
$prep = $pdo->prepare($sql);

$prep->execute();
$user = $prep->fetchAll();

$smarty = new Smarty();
            $smarty->assign([
                "posts" => $user
      
            ]);
            $smarty->display("temp/inscription.tpl");

require("includes/bas.inc.php");


?>