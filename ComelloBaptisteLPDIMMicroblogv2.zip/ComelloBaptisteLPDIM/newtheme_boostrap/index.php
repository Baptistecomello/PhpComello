<?php 
require("libs/Smarty.class.php");

require("includes/haut.inc.php");

require("includes/connexion.inc.php");

$sql = "SELECT * FROM messages";
$prep = $pdo->prepare($sql);

$prep->execute();
$data = $prep->fetch();

$smarty = new Smarty();
            $smarty->assign([
                "tab" => $data
      
            ]);
            $smarty->display("temp/index.tpl");

require("includes/bas.inc.php");


?>