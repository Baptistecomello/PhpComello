<?php
/* Smarty version 3.1.33, created on 2019-03-31 22:37:49
  from 'D:\Xampp\htdocs\newtheme_boostrap\temp\index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5ca1251d0bc8e7_12683059',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '97efea97ff6b1806773e255971d565b87114d1ea' => 
    array (
      0 => 'D:\\Xampp\\htdocs\\newtheme_boostrap\\temp\\index.tpl',
      1 => 1554064654,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5ca1251d0bc8e7_12683059 (Smarty_Internal_Template $_smarty_tpl) {
?><section>
    <div class="container">
        <div class="row">
            <form action="message.php" method="POST">
                <div class="col-sm-10">
                    <div class="form-group">
                    <?php if (isset($_smarty_tpl->tpl_vars['post']->value['id'])) {?>
                  
                        <textarea id="message" name="message" class="form-control" placeholder="Message"> <?php echo $_smarty_tpl->tpl_vars['post']->value['contenu'];?>
</textarea>
                    
                    <?php } else { ?> 
                        <textarea id="message" name="message" class="form-control" placeholder="Message"> </textarea>
                    <?php }?>
                        <input type="hidden" name="id" values=<?php echo $_smarty_tpl->tpl_vars['post']->value['id'];
echo '?>';?> 
                        <input type="file" id="image" name="image" class="form-control">
                    </div>
                </div>
                <div class="col-sm-2">
                    <button type="submit" class="btn btn-success btn-lg">Envoyer</button>
                </div>
            </form>
        </div>

        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['tab']->value, 'post', false, 'key');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['key']->value => $_smarty_tpl->tpl_vars['post']->value) {
?>
        
        
            <div class="row">
                <div class="col-md-12">
                    <blockquote>
                        <p>
                            <?php echo $_smarty_tpl->tpl_vars['post']->value['contenu'];?>

                        </p>
                        <footer>
                            <?php if (isset($_smarty_tpl->tpl_vars['post']->value['image']) && file_exists("uploads/images/".((string)$_smarty_tpl->tpl_vars['post']->value['image']))) {?>
                                <img class="img-thumbnail" src="vignette.php?id=<?php echo $_smarty_tpl->tpl_vars['post']->value['image'];?>
" alt="<?php echo $_smarty_tpl->tpl_vars['post']->value['image'];?>
">
                            <?php }?>
                            <p><?php echo $_smarty_tpl->tpl_vars['post']->value['date'];?>
</p>
                            <a class="btn btn-secondary" href="index.php?id=<?php echo $_smarty_tpl->tpl_vars['post']->value['id'];?>
">">Modifier</a>
                            <a  class="btn btn-secondary" href="supprimer.php?id=<?php echo $_smarty_tpl->tpl_vars['post']->value['id'];?>
"> Supprimer</a>
                            <a class="btn btn-secondary" name="like" id=<?php echo $_smarty_tpl->tpl_vars['post']->value['id'];?>
">J'aime</a>
                            <a class="btn btn-secondary" id="compteLike"><?php echo $_smarty_tpl->tpl_vars['post']->value['id'];?>
"</a>
                        </footer>
                    </blockquote>
                </div>
            </div>
        
        <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
    </section><?php }
}
