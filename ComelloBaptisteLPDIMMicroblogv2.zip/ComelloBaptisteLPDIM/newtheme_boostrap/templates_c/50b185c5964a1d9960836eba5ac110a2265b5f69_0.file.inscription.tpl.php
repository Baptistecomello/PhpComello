<?php
/* Smarty version 3.1.33, created on 2019-03-31 20:52:48
  from 'D:\Xampp\htdocs\newtheme_boostrap\temp\inscription.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5ca10c806fda84_05466767',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '50b185c5964a1d9960836eba5ac110a2265b5f69' => 
    array (
      0 => 'D:\\Xampp\\htdocs\\newtheme_boostrap\\temp\\inscription.tpl',
      1 => 1554058345,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5ca10c806fda84_05466767 (Smarty_Internal_Template $_smarty_tpl) {
?> <section>
    <div class="container p-3 p-md-5">


    <br>
    <form action="addUser.php" method="POST">
      <div class="form-row">
        <div class="form-group col-6">
          <label for="pseudoxd">Nom</label>
          <input id="pseudo" name="pseudo" type="text" class="form-control" placeholder="Pseudo"/>

        </div>
        <div class="form-group col-6">
          <label for="pwdxd">Mot de passe</label>
          <input id="pwd_in" name="pwd_in" type="password" class="form-control" placeholder="Mot de passe"/>
        </div>
      </div>


       <button class="btn btn-primary" type="submit">Inscription</button>

  
    </form>   
    <hr>
    </div>

<section><?php }
}
