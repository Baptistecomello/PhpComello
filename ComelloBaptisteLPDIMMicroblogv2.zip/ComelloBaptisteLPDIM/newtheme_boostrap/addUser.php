<?php
include("includes/connexion.inc.php");

    $query = "INSERT INTO user(pseudo, pwd) VALUES(:pseudo, :pwd)";
    $prep = $pdo->prepare($query);
    $prep->bindValue(':pseudo', $_POST['pseudo']);
    $prep->bindValue(':pwd', $_POST['pwd_in']);
    $prep->execute();
    header("Location:index.php");

?>  